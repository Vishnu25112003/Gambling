import * as THREE from 'three';

const stage = document.querySelector('three-d-stage');
const {} = await stage.ready;

/* ---------- materials ---------- */
// Skin reads as skin from three cues: a warm sheen (low-but-present specular),
// a touch of translucency at the edges, and slightly reddened fingertips.
function skin(name, color, sheen) {
  return new THREE.MeshPhysicalMaterial({
    name, color,
    roughness: 0.52, metalness: 0.0,
    clearcoat: 0.22, clearcoatRoughness: 0.6,
    sheen: 0.55, sheenRoughness: 0.75, sheenColor: new THREE.Color(sheen),
    transmission: 0.0, ior: 1.4,
    flatShading: false
  });
}

const M = {
  skinL: skin('skin_left', 0xd8a480, 0xff9a7a),
  skinR: skin('skin_right', 0xa9714a, 0xd4694a),
  tipL: skin('fingertip_left', 0xd0906f, 0xff8f6c),
  tipR: skin('fingertip_right', 0xa06342, 0xcc5c40),
  nail: new THREE.MeshPhysicalMaterial({
    name: 'nail', color: 0xe8c6b4, roughness: 0.18, metalness: 0.0,
    clearcoat: 0.9, clearcoatRoughness: 0.12
  }),
  cuffL: new THREE.MeshStandardMaterial({ name: 'sleeve_left', color: 0x27506e, roughness: 0.95 }),
  cuffR: new THREE.MeshStandardMaterial({ name: 'sleeve_right', color: 0x6a2a2f, roughness: 0.95 }),
  band: new THREE.MeshStandardMaterial({ name: 'wristband', color: 0xcfc6b8, roughness: 0.9 })
};

/* ---------- geometry helpers ---------- */
function roundedBox(w, h, d, r) {
  const s = new THREE.Shape();
  const x = -w / 2, y = -h / 2;
  s.moveTo(x + r, y);
  s.lineTo(x + w - r, y);
  s.quadraticCurveTo(x + w, y, x + w, y + r);
  s.lineTo(x + w, y + h - r);
  s.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
  s.lineTo(x + r, y + h);
  s.quadraticCurveTo(x, y + h, x, y + h - r);
  s.lineTo(x, y + r);
  s.quadraticCurveTo(x, y, x + r, y);
  const bev = Math.min(d * 0.36, 0.009);
  const g = new THREE.ExtrudeGeometry(s, {
    depth: d - bev * 2, bevelEnabled: true, bevelThickness: bev,
    bevelSize: bev, bevelSegments: 6, curveSegments: 14
  });
  g.translate(0, 0, -(d - bev * 2) / 2);
  g.computeVertexNormals();
  return g;
}

function bone(r, L) {
  const g = new THREE.CapsuleGeometry(r, Math.max(L - 2 * r, 0.002), 8, 26);
  g.translate(0, L / 2, 0);
  return g;
}

/* ---------- finger rig ---------- */
// Local hand space: palm faces +z, fingers point +y, wrist at y = 0.
// Curl = rotation about +x (fingertips swing toward the viewer, then down).
function buildFinger(prefix, lengths, radius, skinMat, tipMat, withNail = true) {
  const joints = [];
  let parent = null;
  const root = new THREE.Object3D();
  root.name = prefix + '_root';
  parent = root;

  for (let i = 0; i < lengths.length; i++) {
    const j = new THREE.Object3D();
    j.name = `${prefix}_j${i + 1}`;
    if (i > 0) j.position.y = lengths[i - 1] - radius * Math.pow(0.88, i) * 0.72;
    parent.add(j);
    const r = radius * Math.pow(0.88, i);
    const last = i === lengths.length - 1;
    const m = new THREE.Mesh(bone(r, lengths[i]), last ? tipMat : skinMat);
    m.name = `${prefix}_p${i + 1}`;
    j.add(m);
    // Knuckle: a slight bulge over the joint keeps the finger one continuous form.
    const k = new THREE.Mesh(new THREE.SphereGeometry(r * 1.06, 24, 18), skinMat);
    k.name = `${prefix}_k${i + 1}`;
    k.scale.set(1, 0.78, 1.02);
    j.add(k);
    if (last && withNail) {
      const n = new THREE.Mesh(new THREE.SphereGeometry(r * 0.60, 24, 16), M.nail);
      n.name = `${prefix}_nail`;
      n.scale.set(1.05, 1.5, 0.34);
      n.position.set(0, lengths[i] * 0.60, -r * 0.80);
      n.rotation.x = 0.20;
      j.add(n);
    }
    joints.push(j);
    parent = j;
  }
  return { root, joints };
}

/* ---------- hand ---------- */
function buildHand(side /* +1 left, -1 right */, tag, skinMat, tipMat, sleeve) {
  const s = side;
  const hand = new THREE.Object3D();
  hand.name = tag + '_hand';

  const PW = 0.084, PH = 0.096, PD = 0.030;
  const palm = new THREE.Mesh(roundedBox(PW, PH, PD, 0.018), skinMat);
  palm.name = tag + '_palm';
  palm.position.y = PH / 2;
  hand.add(palm);

  // thenar (thumb-side) and hypothenar muscle bulges — the silhouette cue
  const thenar = new THREE.Mesh(new THREE.SphereGeometry(0.022, 26, 18), skinMat);
  thenar.name = tag + '_thenar';
  thenar.scale.set(1.12, 1.45, 0.82);
  thenar.position.set(s * 0.026, 0.030, 0.004);
  hand.add(thenar);

  const hypo = new THREE.Mesh(new THREE.SphereGeometry(0.017, 24, 16), skinMat);
  hypo.name = tag + '_hypothenar';
  hypo.scale.set(0.92, 1.72, 0.78);
  hypo.position.set(-s * 0.030, 0.036, 0.001);
  hand.add(hypo);

  // knuckle pad across the top of the palm
  const knuckles = new THREE.Mesh(roundedBox(PW * 0.98, 0.026, PD * 0.98, 0.012), skinMat);
  knuckles.name = tag + '_knuckles';
  knuckles.position.set(0, PH - 0.006, 0.001);
  hand.add(knuckles);

  // wrist + cuff
  const wrist = new THREE.Mesh(new THREE.CylinderGeometry(0.0255, 0.0285, 0.056, 34, 1), skinMat);
  wrist.name = tag + '_wrist';
  wrist.scale.z = 0.76;
  wrist.position.y = -0.024;
  hand.add(wrist);

  const cuff = new THREE.Mesh(new THREE.CylinderGeometry(0.0315, 0.0345, 0.056, 36, 1), sleeve);
  cuff.name = tag + '_cuff';
  cuff.scale.z = 0.80;
  cuff.position.y = -0.056;
  hand.add(cuff);

  const band = new THREE.Mesh(new THREE.TorusGeometry(0.0295, 0.005, 16, 48), M.band);
  band.name = tag + '_band';
  band.rotation.x = Math.PI / 2;
  band.scale.y = 0.80;
  band.position.y = -0.032;
  hand.add(band);

  // four fingers
  const spec = [
    { n: 'index',  L: [0.043, 0.027, 0.022], r: 0.0098, x: 0.029, y: 0.0930, z: 0.001, splay:  0.10 },
    { n: 'middle', L: [0.047, 0.031, 0.024], r: 0.0102, x: 0.0098, y: 0.0972, z: 0.003, splay:  0.02 },
    { n: 'ring',   L: [0.043, 0.029, 0.023], r: 0.0095, x: -0.0098, y: 0.0942, z: 0.002, splay: -0.055 },
    { n: 'pinky',  L: [0.034, 0.022, 0.019], r: 0.0080, x: -0.0295, y: 0.0862, z: -0.001, splay: -0.145 }
  ];
  const fingers = spec.map(f => {
    const rig = buildFinger(`${tag}_${f.n}`, f.L, f.r, skinMat, tipMat);
    rig.root.position.set(s * f.x, f.y, f.z);
    rig.splay = f.splay;
    hand.add(rig.root);
    return rig;
  });

  // thumb
  const thumb = buildFinger(`${tag}_thumb`, [0.040, 0.030], 0.0122, skinMat, tipMat, true);
  thumb.root.position.set(s * 0.033, 0.028, 0.009);
  hand.add(thumb.root);

  return { hand, fingers, thumb, side: s };
}

/* ---------- poses ---------- */
// curls: index, middle, ring, pinky (0 = straight, 1 = folded into the palm)
const POSES = {
  1: { curls: [0, 1, 1, 1], thumb: 1, open: 0.35, label: 'index' },
  2: { curls: [0, 0, 1, 1], thumb: 1, open: 0.55, label: 'peace' },
  3: { curls: [0, 0, 0, 1], thumb: 1, open: 0.7, label: 'three' },
  4: { curls: [0, 0, 0, 0], thumb: 1, open: 0.85, label: 'four' },
  5: { curls: [0, 0, 0, 0], thumb: 0, open: 1.0, label: 'open' },
  6: { curls: [1, 1, 1, 1], thumb: 0, open: 0.0, label: 'thumb' }
};

function poseTargets(rig, n) {
  const p = POSES[n], s = rig.side, t = [];
  rig.fingers.forEach((f, i) => {
    const c = p.curls[i];
    const bend = [c * 1.46 + 0.09, c * 1.80 + 0.14, c * 1.24 + 0.10];
    t.push({ o: f.joints[0], x: bend[0], z: -s * f.splay * p.open * (1 - c) });
    t.push({ o: f.joints[1], x: bend[1], z: 0 });
    t.push({ o: f.joints[2], x: bend[2], z: 0 });
  });
  const tc = p.thumb;
  t.push({
    o: rig.thumb.joints[0],
    x: 0.20 + tc * 0.50,
    y: -s * tc * 0.85,
    z: -s * (0.98 - tc * 0.60)
  });
  t.push({ o: rig.thumb.joints[1], x: 0.10 + tc * 1.05, z: 0 });
  return t;
}

/* ---------- scene ---------- */
const model = new THREE.Group();
model.name = 'hand_cricket_hands';

const L = buildHand(1, 'left', M.skinL, M.tipL, M.cuffL);
const R = buildHand(-1, 'right', M.skinR, M.tipR, M.cuffR);
L.hand.position.set(-0.100, 0, 0);
L.hand.rotation.set(-0.08, 0.16, 0.05);
R.hand.position.set(0.100, 0, 0);
R.hand.rotation.set(-0.08, -0.16, -0.05);
model.add(L.hand, R.hand);

model.traverse(o => { if (o.isMesh) { o.castShadow = true; o.receiveShadow = true; } });

// The stage's built-in orbit hint is styled for its light default background and
// duplicates the page subhead — drop it now that the backdrop is a dark stadium.
stage.shadowRoot?.querySelector('.note')?.remove();

stage.setObject(model);

/* ---------- posing + smoothing ---------- */
const state = { left: 1, right: 1 };
let targets = [];
function retarget() {
  targets = [...poseTargets(L, state.left), ...poseTargets(R, state.right)];
}
retarget();
targets.forEach(t => t.o.rotation.set(t.x || 0, t.y || 0, t.z || 0));

let last = performance.now();
(function tick(now) {
  requestAnimationFrame(tick);
  const dt = Math.min(((now || performance.now()) - last) / 1000, 0.2);
  last = now || performance.now();
  const k = 1 - Math.exp(-dt * 16);
  for (const t of targets) {
    const r = t.o.rotation;
    r.x += ((t.x || 0) - r.x) * k;
    r.y += ((t.y || 0) - r.y) * k;
    r.z += ((t.z || 0) - r.z) * k;
  }
})();

/* ---------- UI ---------- */
const callout = document.getElementById('callout');
function refresh() {
  retarget();
  // If the frame loop is throttled (background tab), snap instead of easing.
  if (performance.now() - last > 400) {
    targets.forEach(t => t.o.rotation.set(t.x || 0, t.y || 0, t.z || 0));
  }
  for (const [key, side] of [['L', 'left'], ['R', 'right']]) {
    const v = state[side];
    document.getElementById('lbl-' + key).textContent = `${v} — ${POSES[v].label}`;
    document.querySelectorAll(`#row-${key} button`).forEach(b => {
      b.setAttribute('aria-pressed', String(+b.dataset.n === v));
    });
  }
  callout.textContent = `Left ${state.left} · Right ${state.right}` +
    (state.left === state.right ? '  ·  OUT' : `  ·  ${state.left + state.right} runs`);
}

for (const [key, side] of [['L', 'left'], ['R', 'right']]) {
  const row = document.getElementById('row-' + key);
  for (let n = 1; n <= 6; n++) {
    const b = document.createElement('button');
    b.className = 'sign';
    b.dataset.n = n;
    b.innerHTML = `${n}<span>${POSES[n].label}</span>`;
    b.onclick = () => { state[side] = n; refresh(); };
    row.appendChild(b);
  }
}
addEventListener('keydown', e => {
  const m = /^Digit([1-6])$/.exec(e.code);
  const n = m ? +m[1] : 0;
  if (n) { state[e.shiftKey ? 'right' : 'left'] = n; refresh(); }
});
refresh();
