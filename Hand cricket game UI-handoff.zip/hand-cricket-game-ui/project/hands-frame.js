// <hands-frame src left right shake> — iframe host for the 3D hand stage.
// Forwards pose changes to the guest page over postMessage.
class HandsFrame extends HTMLElement {
  static get observedAttributes() { return ['src', 'left', 'right', 'shake']; }

  connectedCallback() {
    if (this._frame) return;
    this.style.display = 'block';
    this.style.position = 'absolute';
    this.style.inset = '0';
    const f = document.createElement('iframe');
    f.style.cssText = 'width:100%;height:100%;border:0;display:block;background:transparent';
    f.setAttribute('title', 'hand signs');
    f.setAttribute('allowtransparency', 'true');
    f.src = this.getAttribute('src') || './hands-stage.html';
    this._frame = f;
    this.appendChild(f);
    this._onMsg = e => {
      if (e.source === f.contentWindow && e.data && e.data.type === 'hands-ready') {
        this._ready = true;
        this._send();
      }
    };
    addEventListener('message', this._onMsg);
  }

  disconnectedCallback() { removeEventListener('message', this._onMsg); }

  attributeChangedCallback(name, _o, v) {
    if (name === 'src' && this._frame && v) this._frame.src = v;
    else this._send();
  }

  _send() {
    if (!this._ready || !this._frame) return;
    const num = a => { const n = Number(this.getAttribute(a)); return Number.isFinite(n) ? n : 0; };
    this._frame.contentWindow.postMessage({
      type: 'hands', left: num('left'), right: num('right'), shake: num('shake')
    }, '*');
  }
}
if (!customElements.get('hands-frame')) customElements.define('hands-frame', HandsFrame);
