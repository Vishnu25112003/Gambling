import * as THREE from 'three';

function makeStripe(colorA, colorB) {
  const c = document.createElement('canvas'); c.width = 512; c.height = 64;
  const ctx = c.getContext('2d'); const n = 96;
  for (let i = 0; i < n; i++) { ctx.fillStyle = i % 2 === 0 ? colorA : colorB; ctx.fillRect(i * (c.width / n), 0, c.width / n, c.height); }
  const tex = new THREE.CanvasTexture(c);
  tex.wrapS = THREE.RepeatWrapping; tex.wrapT = THREE.RepeatWrapping;
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}
function drawStar(ctx, cx, cy, r, rot) {
  ctx.beginPath();
  for (let i = 0; i < 10; i++) {
    const ang = rot + i * Math.PI / 5, rad = i % 2 === 0 ? r : r * 0.42;
    const x = cx + Math.cos(ang) * rad, y = cy + Math.sin(ang) * rad;
    if (i === 0) { ctx.moveTo(x, y); } else { ctx.lineTo(x, y); }
  }
  ctx.closePath();
}
function makeFaceTexture(letter) {
  const c = document.createElement('canvas'); c.width = 512; c.height = 512;
  const ctx = c.getContext('2d'); const cx = 256, cy = 256;
  const grad = ctx.createRadialGradient(cx - 70, cy - 80, 30, cx, cy, 300);
  grad.addColorStop(0, '#fff8dc'); grad.addColorStop(0.5, '#ffd35c'); grad.addColorStop(1, '#c9962a');
  ctx.fillStyle = grad; ctx.beginPath(); ctx.arc(cx, cy, 250, 0, Math.PI * 2); ctx.fill();
  ctx.strokeStyle = '#a9791f'; ctx.lineWidth = 5;
  ctx.beginPath(); ctx.arc(cx, cy, 224, 0, Math.PI * 2); ctx.stroke();
  ctx.beginPath(); ctx.arc(cx, cy, 196, 0, Math.PI * 2); ctx.stroke();
  ctx.fillStyle = '#b5842a';
  for (let i = 0; i < 12; i++) {
    const a = (i / 12) * Math.PI * 2 - Math.PI / 2;
    drawStar(ctx, cx + Math.cos(a) * 210, cy + Math.sin(a) * 210, 10, a); ctx.fill();
  }
  ctx.save();
  ctx.font = '800 230px Georgia, serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
  ctx.fillStyle = 'rgba(140,95,20,0.55)'; ctx.fillText(letter, cx + 5, cy + 7);
  ctx.fillStyle = '#8a5f14'; ctx.fillText(letter, cx, cy);
  ctx.restore();
  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}
function easeOutExpo(t) { return t >= 1 ? 1 : 1 - Math.pow(2, -10 * t); }

var SPIN_SPEED = 430;

export function mountCoin(container) {
  var renderer;
  try {
    renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true, preserveDrawingBuffer: true });
  } catch (e) {
    var canvas = document.createElement('canvas');
    var gl = canvas.getContext('webgl2', { antialias: true, alpha: true, preserveDrawingBuffer: true }) ||
             canvas.getContext('webgl', { antialias: true, alpha: true, preserveDrawingBuffer: true });
    renderer = new THREE.WebGLRenderer({ canvas: canvas, context: gl, antialias: true, alpha: true, preserveDrawingBuffer: true });
  }
  renderer.setClearColor(0x000000, 0);
  renderer.domElement.style.width = '100%'; renderer.domElement.style.height = '100%'; renderer.domElement.style.display = 'block';
  container.appendChild(renderer.domElement);

  var scene = new THREE.Scene();
  var camera = new THREE.PerspectiveCamera(30, 1, 0.1, 10);
  camera.position.set(0, 0, 5.0);
  scene.add(new THREE.AmbientLight(0xffffff, 0.55));
  scene.add(new THREE.HemisphereLight(0xfff2d0, 0x2a2010, 0.9));
  var key = new THREE.DirectionalLight(0xfff3d6, 2.4); key.position.set(2.2, 3, 3.5); scene.add(key);
  var rim = new THREE.DirectionalLight(0x22c55e, 0.6); rim.position.set(-3, -1, 2); scene.add(rim);
  var fill = new THREE.DirectionalLight(0xffffff, 1.0); fill.position.set(-2.2, 1.6, 2.6); scene.add(fill);

  var outer = new THREE.Group(); scene.add(outer);
  var coinGroup = new THREE.Group(); outer.add(coinGroup);

  var R = 0.82, T = 0.18;
  var geo = new THREE.CylinderGeometry(R, R, T, 72, 1, false);
  geo.rotateX(Math.PI / 2);
  var sideMap = makeStripe('#ffe9a8', '#a9791f'); sideMap.repeat.set(40, 1);
  var sideMat = new THREE.MeshStandardMaterial({ map: sideMap, metalness: 0.7, roughness: 0.4, color: 0xffe9a8 });
  var headsTex = makeFaceTexture('H'), tailsTex = makeFaceTexture('T');
  var headsMat = new THREE.MeshStandardMaterial({ map: headsTex, metalness: 0.55, roughness: 0.32, color: 0xffffff });
  var tailsMat = new THREE.MeshStandardMaterial({ map: tailsTex, metalness: 0.55, roughness: 0.32, color: 0xffffff });
  var mesh = new THREE.Mesh(geo, [sideMat, headsMat, tailsMat]);
  mesh.name = 'coin';
  coinGroup.add(mesh);
  outer.rotation.x = 0.22; outer.rotation.z = -0.1;

  var state = { angle: 0, tween: null, spinning: false, raf: null, disposed: false };

  function resize() {
    var w = container.clientWidth || 220, h = container.clientHeight || 220;
    renderer.setPixelRatio(Math.min(2, window.devicePixelRatio || 1));
    renderer.setSize(w, h, false);
    camera.aspect = w / h;
    camera.updateProjectionMatrix();
  }
  var ro = new ResizeObserver(resize);
  ro.observe(container);
  resize();

  var t0 = performance.now();
  var lastNow = t0;
  function loop() {
    if (state.disposed) return;
    var now = performance.now();
    var frameDt = (now - lastNow) / 1000; lastNow = now;
    var dt = (now - t0) / 1000;
    if (state.tween) {
      var tw = state.tween;
      var t = Math.min(1, (now - tw.start) / Math.max(1, tw.dur));
      state.angle = tw.from + (tw.to - tw.from) * easeOutExpo(t);
      if (t >= 1) state.tween = null;
    } else if (state.spinning) {
      state.angle += SPIN_SPEED * frameDt;
    }
    coinGroup.rotation.y = state.angle * Math.PI / 180;
    outer.position.y = Math.sin(dt * 1.1) * 0.05;
    outer.rotation.x = 0.22 + Math.sin(dt * 0.7) * 0.025;
    renderer.render(scene, camera);
    state.raf = requestAnimationFrame(loop);
  }
  state.raf = requestAnimationFrame(loop);

  return {
    setTarget: function (deg, durationMs, instant) {
      if (instant) { state.tween = null; state.angle = deg; return; }
      if (deg === state.angle && !state.tween) return;
      state.tween = { from: state.angle, to: deg, dur: durationMs || 1200, start: performance.now() };
    },
    setSpinning: function (on) { state.spinning = !!on; },
    dispose: function () {
      state.disposed = true;
      if (state.raf) cancelAnimationFrame(state.raf);
      ro.disconnect();
      renderer.dispose();
      if (renderer.domElement.parentNode) renderer.domElement.parentNode.removeChild(renderer.domElement);
    }
  };
}
