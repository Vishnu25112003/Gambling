// Procedural print artwork for the trump-card package (canvas textures).
const PAL = {
  ink: '#17141b', crimson: '#d8232a', gold: '#f5c518', cream: '#f6f1e4',
  blue: '#1e57b3', orange: '#f2762e', teal: '#1f9e8f', purple: '#6b3fa0',
};

function cv(w, h) {
  const c = document.createElement('canvas');
  c.width = w; c.height = h;
  return [c, c.getContext('2d')];
}

function burst(ctx, w, h, a, b) {
  const g = ctx.createRadialGradient(w * 0.5, h * 0.42, 4, w * 0.5, h * 0.42, w * 0.9);
  g.addColorStop(0, a); g.addColorStop(1, b);
  ctx.fillStyle = g; ctx.fillRect(0, 0, w, h);
  ctx.save();
  ctx.translate(w * 0.5, h * 0.42);
  ctx.globalAlpha = 0.16; ctx.fillStyle = '#fff';
  for (let i = 0; i < 24; i++) {
    ctx.rotate(Math.PI * 2 / 24);
    ctx.beginPath(); ctx.moveTo(0, 0);
    ctx.lineTo(w * 1.4, -w * 0.035); ctx.lineTo(w * 1.4, w * 0.035);
    ctx.closePath(); ctx.fill();
  }
  ctx.restore();
}

function halftone(ctx, w, h, color, step, r, alpha) {
  ctx.save(); ctx.globalAlpha = alpha; ctx.fillStyle = color;
  for (let y = 0; y < h; y += step) for (let x = 0; x < w; x += step) {
    ctx.beginPath(); ctx.arc(x + (y / step % 2) * step / 2, y, r, 0, 7); ctx.fill();
  }
  ctx.restore();
}

// Low-slung car in side profile — a stand-in until real vehicle art lands.
function car(ctx, x, y, s, paint, glass, trim) {
  ctx.save(); ctx.translate(x, y); ctx.scale(s, s);
  ctx.fillStyle = 'rgba(0,0,0,0.25)';
  ctx.beginPath(); ctx.ellipse(0, 74, 196, 16, 0, 0, 7); ctx.fill();
  ctx.fillStyle = paint;                                   // body
  ctx.beginPath();
  ctx.moveTo(-186, 44);
  ctx.quadraticCurveTo(-192, 10, -150, 4);
  ctx.lineTo(-96, 0);
  ctx.quadraticCurveTo(-58, -62, 6, -64);
  ctx.quadraticCurveTo(74, -64, 108, -4);
  ctx.lineTo(160, 6);
  ctx.quadraticCurveTo(192, 14, 188, 46);
  ctx.closePath(); ctx.fill();
  ctx.fillStyle = glass;                                   // cabin glass
  ctx.beginPath();
  ctx.moveTo(-78, -6); ctx.quadraticCurveTo(-48, -50, 2, -52);
  ctx.quadraticCurveTo(58, -52, 88, -8); ctx.closePath(); ctx.fill();
  ctx.fillStyle = 'rgba(255,255,255,0.35)';
  ctx.beginPath(); ctx.moveTo(-70, -10); ctx.lineTo(-34, -44); ctx.lineTo(-14, -44);
  ctx.lineTo(-52, -10); ctx.closePath(); ctx.fill();
  ctx.fillStyle = trim;                                    // splitter + intake
  ctx.fillRect(-190, 40, 66, 12);
  ctx.fillRect(124, 40, 66, 12);
  ctx.fillStyle = PAL.gold;                                // headlamp
  ctx.beginPath(); ctx.moveTo(-186, 10); ctx.lineTo(-142, 4); ctx.lineTo(-142, 20);
  ctx.lineTo(-186, 24); ctx.closePath(); ctx.fill();
  ctx.fillStyle = PAL.crimson;                             // tail lamp
  ctx.fillRect(156, 12, 30, 12);
  [-108, 104].forEach((wx) => {                            // wheels
    ctx.fillStyle = '#15161a';
    ctx.beginPath(); ctx.arc(wx, 44, 48, 0, 7); ctx.fill();
    ctx.fillStyle = '#b9bec8';
    ctx.beginPath(); ctx.arc(wx, 44, 25, 0, 7); ctx.fill();
    ctx.fillStyle = '#15161a';
    ctx.beginPath(); ctx.arc(wx, 44, 9, 0, 7); ctx.fill();
  });
  ctx.restore();
}
const bust = car;

function outlined(ctx, text, x, y, size, fill, stroke, font = '900') {
  ctx.font = `${font} ${size}px "Arial Black", Impact, system-ui, sans-serif`;
  ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
  ctx.lineJoin = 'round'; ctx.lineWidth = size * 0.22;
  ctx.strokeStyle = stroke; ctx.strokeText(text, x, y);
  ctx.fillStyle = fill; ctx.fillText(text, x, y);
}

export function cardFace(spec) {
  const W = 560, H = 860, [c, ctx] = cv(W, H);
  ctx.fillStyle = PAL.cream; ctx.fillRect(0, 0, W, H);
  const M = 22;
  // art panel
  ctx.save();
  ctx.beginPath(); ctx.rect(M, M + 54, W - M * 2, 400); ctx.clip();
  burst(ctx, W, H, spec.art[0], spec.art[1]);
  halftone(ctx, W, H, '#000', 16, 2.4, 0.10);
  car(ctx, W * 0.5, 330, 1.12, spec.paint, '#20304a', spec.trim);
  ctx.restore();
  ctx.strokeStyle = PAL.ink; ctx.lineWidth = 6;
  ctx.strokeRect(M, M + 54, W - M * 2, 400);

  // suit header
  ctx.fillStyle = PAL.ink; ctx.fillRect(M, M, W - M * 2, 54);
  ctx.fillStyle = PAL.gold; ctx.fillRect(M, M, 132, 54);
  ctx.fillStyle = PAL.ink;
  ctx.font = '900 38px Georgia, serif'; ctx.textAlign = 'left'; ctx.textBaseline = 'middle';
  ctx.fillText(spec.rank + ' ' + spec.suit, M + 16, M + 28);
  ctx.fillStyle = PAL.cream; ctx.font = '700 26px system-ui, sans-serif';
  ctx.fillText('TRUMP 52', M + 152, M + 29);

  // name band
  ctx.fillStyle = PAL.crimson; ctx.fillRect(M, 480, W - M * 2, 62);
  ctx.fillStyle = '#fff'; ctx.font = '900 36px system-ui, sans-serif';
  ctx.fillText(spec.name.toUpperCase(), M + 16, 512);

  // stat table — 6 options
  ctx.fillStyle = PAL.gold; ctx.fillRect(M, 552, W - M * 2, 262);
  ctx.strokeStyle = PAL.ink; ctx.lineWidth = 5; ctx.strokeRect(M, 552, W - M * 2, 262);
  ctx.font = '800 27px system-ui, sans-serif';
  spec.stats.forEach(([k, v], i) => {
    const col = i % 2, row = (i / 2) | 0;
    const x = M + 18 + col * 258, y = 586 + row * 82;
    ctx.fillStyle = PAL.ink; ctx.textAlign = 'left';
    ctx.fillText('• ' + k, x, y);
    ctx.fillStyle = PAL.crimson; ctx.font = '900 40px "Arial Black", system-ui, sans-serif';
    ctx.fillText(String(v), x + 14, y + 36);
    ctx.font = '800 27px system-ui, sans-serif';
  });
  ctx.fillStyle = PAL.ink; ctx.textAlign = 'center'; ctx.font = '700 20px system-ui, sans-serif';
  ctx.fillText('ORIGINAL DATA  ·  52 CARD DECK', W / 2, 838);
  return c;
}

export function cardBack() {
  const W = 560, H = 860, [c, ctx] = cv(W, H);
  ctx.fillStyle = PAL.cream; ctx.fillRect(0, 0, W, H);
  ctx.save(); ctx.translate(28, 28);
  const w = W - 56, h = H - 56;
  ctx.beginPath(); ctx.rect(0, 0, w, h); ctx.clip();
  burst(ctx, w, h, PAL.orange, PAL.crimson);
  halftone(ctx, w, h, PAL.ink, 20, 3, 0.14);
  ctx.save(); ctx.translate(w / 2, h / 2);
  ctx.rotate(-0.18);
  outlined(ctx, 'TRUMP', 0, -70, 104, PAL.gold, PAL.ink);
  outlined(ctx, '52', 0, 60, 168, PAL.cream, PAL.ink);
  ctx.restore();
  ctx.restore();
  ctx.strokeStyle = PAL.ink; ctx.lineWidth = 7; ctx.strokeRect(28, 28, W - 56, H - 56);
  return c;
}

export function boxFront() {
  const W = 560, H = 810, [c, ctx] = cv(W, H);
  burst(ctx, W, H, PAL.blue, '#0b1b3f');
  halftone(ctx, W, H, '#fff', 18, 2.2, 0.10);
  car(ctx, W * 0.5, H * 0.52, 1.32, PAL.crimson, '#20304a', PAL.gold);
  ctx.fillStyle = 'rgba(11,17,33,0.55)'; ctx.fillRect(0, 0, W, 150);
  outlined(ctx, 'TRUMP 52', W / 2, 78, 86, PAL.gold, PAL.ink);
  ctx.fillStyle = PAL.crimson; ctx.fillRect(0, H - 178, W, 118);
  ctx.save(); ctx.translate(0, 0);
  outlined(ctx, 'SUPERCARS', W / 2, H - 138, 62, PAL.cream, PAL.ink);
  ctx.restore();
  ctx.fillStyle = PAL.gold; ctx.fillRect(0, H - 60, W, 60);
  ctx.fillStyle = PAL.ink; ctx.font = '800 30px system-ui, sans-serif';
  ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
  ctx.fillText('52 CARDS · 6 STATS EACH', W / 2, H - 29);
  ctx.strokeStyle = PAL.ink; ctx.lineWidth = 10; ctx.strokeRect(0, 0, W, H);
  return c;
}

export function boxBack() {
  const W = 560, H = 810, [c, ctx] = cv(W, H);
  ctx.fillStyle = PAL.ink; ctx.fillRect(0, 0, W, H);
  halftone(ctx, W, H, '#fff', 22, 2, 0.07);
  outlined(ctx, 'HOW TO PLAY', W / 2, 84, 56, PAL.gold, '#000');
  ctx.fillStyle = PAL.cream; ctx.font = '700 30px system-ui, sans-serif';
  ctx.textAlign = 'left'; ctx.textBaseline = 'middle';
  ['1. Deal all 52 cards face down.', '2. Caller names one spec.', '3. Best value takes the trick.',
   '4. Lower wins on 0-100 & weight.', '5. Collect every card to win.'].forEach((t, i) => {
    ctx.fillText(t, 52, 190 + i * 62);
  });
  ctx.fillStyle = PAL.crimson; ctx.fillRect(40, 520, W - 80, 200);
  ctx.strokeStyle = PAL.gold; ctx.lineWidth = 6; ctx.strokeRect(40, 520, W - 80, 200);
  ctx.fillStyle = PAL.gold; ctx.font = '900 30px system-ui, sans-serif';
  ctx.textAlign = 'center';
  ['TOP SPEED', 'POWER', '0-100 KM/H', 'TORQUE', 'WEIGHT', 'PRICE'].forEach((s, i) => {
    ctx.fillText(s, W / 2 - 110 + (i % 2) * 220, 566 + ((i / 2) | 0) * 62);
  });
  return c;
}

export function boxSide(label) {
  const W = 190, H = 810, [c, ctx] = cv(W, H);
  ctx.fillStyle = PAL.crimson; ctx.fillRect(0, 0, W, H);
  halftone(ctx, W, H, '#000', 16, 2.4, 0.12);
  ctx.save(); ctx.translate(W / 2, H / 2); ctx.rotate(-Math.PI / 2);
  outlined(ctx, label, 0, 0, 66, PAL.gold, PAL.ink);
  ctx.restore();
  ctx.strokeStyle = PAL.ink; ctx.lineWidth = 10; ctx.strokeRect(0, 0, W, H);
  return c;
}

export function boxCap() {
  const W = 560, H = 190, [c, ctx] = cv(W, H);
  ctx.fillStyle = PAL.gold; ctx.fillRect(0, 0, W, H);
  halftone(ctx, W, H, '#000', 14, 2, 0.10);
  outlined(ctx, 'TRUMP 52', W / 2, H / 2, 62, PAL.ink, PAL.cream);
  ctx.strokeStyle = PAL.ink; ctx.lineWidth = 10; ctx.strokeRect(0, 0, W, H);
  return c;
}

export const CARDS = [
  { rank: 'A', suit: '\u2660', name: 'Vantage GT-R', art: ['#ffd76a', '#1e57b3'], paint: '#d8232a', trim: '#2b2f3a',
    stats: [['TOP SPEED', '340 km/h'], ['POWER', '710 bhp'], ['0-100 KM/H', '2.8 s'], ['TORQUE', '800 Nm'], ['WEIGHT', '1450 kg'], ['PRICE', '\u20b9 3.9 Cr']] },
  { rank: 'K', suit: '\u2663', name: 'Aurora EV1', art: ['#c9f0ff', '#1f9e8f'], paint: '#1e57b3', trim: '#c9ccd4',
    stats: [['TOP SPEED', '290 km/h'], ['POWER', '860 bhp'], ['0-100 KM/H', '2.1 s'], ['TORQUE', '1050 Nm'], ['WEIGHT', '2210 kg'], ['PRICE', '\u20b9 2.4 Cr']] },
  { rank: '7', suit: '\u2665', name: 'Sierra Raptor', art: ['#ffc9a0', '#6b3fa0'], paint: '#f2762e', trim: '#15161a',
    stats: [['TOP SPEED', '250 km/h'], ['POWER', '480 bhp'], ['0-100 KM/H', '4.4 s'], ['TORQUE', '690 Nm'], ['WEIGHT', '1980 kg'], ['PRICE', '\u20b9 1.1 Cr']] },
];
