import * as THREE from 'three';

const stage = document.querySelector('three-d-stage');
const { THREE: T } = await stage.ready;

/* ── deterministic noise ─────────────────────────────────────── */
let seed = 20260816;
const rnd = () => ((seed = (seed * 1664525 + 1013904223) % 4294967296) / 4294967296);
const rng = (a, b) => a + (b - a) * rnd();

/* ── materials (shared, named — they become the MTL entries) ──── */
const M = {
  diceShell: new T.MeshStandardMaterial({
    name: 'dice_shell', color: 0x0e1b12, roughness: 0.28, metalness: 0.35,
    emissive: 0x04170c, emissiveIntensity: 1
  }),
  dicePip: new T.MeshStandardMaterial({
    name: 'dice_pip_neon', color: 0x8cf5a8, roughness: 0.3, metalness: 0.0,
    emissive: 0x3ddc6f, emissiveIntensity: 1.6
  }),
  neonEdge: new T.MeshStandardMaterial({
    name: 'neon_edge', color: 0x27d16b, roughness: 0.4, metalness: 0.0,
    emissive: 0x1fbf5f, emissiveIntensity: 1.5
  }),
  neonSoft: new T.MeshStandardMaterial({
    name: 'neon_soft', color: 0x1c8f4c, roughness: 0.6, metalness: 0.0,
    emissive: 0x117a3d, emissiveIntensity: 0.9
  }),
  deck: new T.MeshStandardMaterial({
    name: 'deck_floor', color: 0x070d09, roughness: 0.55, metalness: 0.2
  }),
  panel: new T.MeshStandardMaterial({
    name: 'panel_dark', color: 0x0a130d, roughness: 0.7, metalness: 0.15
  }),
  coinBody: new T.MeshStandardMaterial({
    name: 'coin_body', color: 0x11331f, roughness: 0.3, metalness: 0.4,
    emissive: 0x0a2916, emissiveIntensity: 1
  }),
  coinRim: new T.MeshStandardMaterial({
    name: 'coin_rim_neon', color: 0x4bf08a, roughness: 0.25, metalness: 0.3,
    emissive: 0x2fd873, emissiveIntensity: 1.4
  }),
  solViolet: new T.MeshStandardMaterial({
    name: 'solana_violet', color: 0x9945ff, roughness: 0.3, metalness: 0.2,
    emissive: 0x6a25cc, emissiveIntensity: 0.8
  }),
  solBlue: new T.MeshStandardMaterial({
    name: 'solana_blue', color: 0x5b7cf5, roughness: 0.3, metalness: 0.2,
    emissive: 0x3a53c0, emissiveIntensity: 0.8
  }),
  solTeal: new T.MeshStandardMaterial({
    name: 'solana_teal', color: 0x19e5b0, roughness: 0.3, metalness: 0.2,
    emissive: 0x0fae87, emissiveIntensity: 0.9
  }),
  shard: new T.MeshStandardMaterial({
    name: 'shard_glass', color: 0x123b23, roughness: 0.15, metalness: 0.35,
    emissive: 0x1c8a4c, emissiveIntensity: 0.7
  })
};

const root = new T.Group();
root.name = 'gamblinghub_hero';

/* ── helpers ─────────────────────────────────────────────────── */
function roundedBoxGeo(size, radius, seg = 4) {
  // shape side is inset by the bevel so the final solid measures exactly `size`
  const side = size - radius * 2;
  const rc = radius;
  const w = side / 2 - rc, h = side / 2 - rc;
  const s = new T.Shape();
  s.moveTo(-w - rc, -h);
  s.lineTo(-w - rc, h);
  s.quadraticCurveTo(-w - rc, h + rc, -w, h + rc);
  s.lineTo(w, h + rc);
  s.quadraticCurveTo(w + rc, h + rc, w + rc, h);
  s.lineTo(w + rc, -h);
  s.quadraticCurveTo(w + rc, -h - rc, w, -h - rc);
  s.lineTo(-w, -h - rc);
  s.quadraticCurveTo(-w - rc, -h - rc, -w - rc, -h);
  const g = new T.ExtrudeGeometry(s, {
    depth: side, bevelEnabled: true, bevelThickness: radius,
    bevelSize: radius, bevelSegments: seg, curveSegments: 12
  });
  g.translate(0, 0, -side / 2);
  g.computeVertexNormals();
  return g;
}

const PIPS = {
  1: [[0, 0]],
  2: [[-1, 1], [1, -1]],
  3: [[-1, 1], [0, 0], [1, -1]],
  4: [[-1, -1], [-1, 1], [1, -1], [1, 1]],
  5: [[-1, -1], [-1, 1], [0, 0], [1, -1], [1, 1]],
  6: [[-1, -1], [-1, 0], [-1, 1], [1, -1], [1, 0], [1, 1]]
};
const FACES = [
  { n: [0, 0, 1], u: [1, 0, 0], v: [0, 1, 0], c: 1 },
  { n: [0, 0, -1], u: [-1, 0, 0], v: [0, 1, 0], c: 6 },
  { n: [1, 0, 0], u: [0, 0, -1], v: [0, 1, 0], c: 3 },
  { n: [-1, 0, 0], u: [0, 0, 1], v: [0, 1, 0], c: 4 },
  { n: [0, 1, 0], u: [1, 0, 0], v: [0, 0, -1], c: 2 },
  { n: [0, -1, 0], u: [1, 0, 0], v: [0, 0, 1], c: 5 }
];

function buildDie(size, label) {
  const die = new T.Group();
  die.name = label;
  const body = new T.Mesh(roundedBoxGeo(size, size * 0.16), M.diceShell);
  body.name = label + '_shell';
  body.castShadow = true; body.receiveShadow = true;
  die.add(body);

  const half = size / 2;
  const pipR = size * 0.092;
  const spread = size * 0.27;
  const pipGeo = new T.SphereGeometry(pipR, 20, 14);
  FACES.forEach((f) => {
    const n = new T.Vector3(...f.n), u = new T.Vector3(...f.u), v = new T.Vector3(...f.v);
    PIPS[f.c].forEach(([a, b], i) => {
      const pip = new T.Mesh(pipGeo, M.dicePip);
      pip.name = `${label}_pip_${f.c}_${i + 1}`;
      pip.position.copy(n).multiplyScalar(half * 0.945)
        .add(u.clone().multiplyScalar(a * spread))
        .add(v.clone().multiplyScalar(b * spread));
      pip.scale.set(1, 1, 1);
      die.add(pip);
    });
  });
  return die;
}

function place(obj, x, y, z, rx, ry, rz) {
  obj.position.set(x, y, z);
  obj.rotation.set(rx, ry, rz);
  return obj;
}

/* ── 1. floor deck + neon grid + ripples ─────────────────────── */
const deck = new T.Group(); deck.name = 'deck';
const floor = new T.Mesh(new T.BoxGeometry(14.5, 0.3, 12), M.deck);
floor.name = 'deck_slab';
floor.position.y = -0.15;
floor.receiveShadow = true;
deck.add(floor);

for (let i = -7; i <= 7; i++) {
  const gx = new T.Mesh(new T.BoxGeometry(0.022, 0.02, 13), M.neonSoft);
  gx.name = `grid_line_x_${i + 8}`;
  gx.position.set(i * 1.05, 0.008, 0);
  deck.add(gx);
  const gz = new T.Mesh(new T.BoxGeometry(14, 0.02, 0.022), M.neonSoft);
  gz.name = `grid_line_z_${i + 8}`;
  gz.position.set(0, 0.008, i * 0.9);
  deck.add(gz);
}
// brighter accent lanes
[-3.4, 3.4].forEach((x, i) => {
  const lane = new T.Mesh(new T.BoxGeometry(0.05, 0.024, 13), M.neonEdge);
  lane.name = `grid_lane_${i + 1}`;
  lane.position.set(x, 0.014, 0);
  deck.add(lane);
});
// ripple rings under the hero die
[1.15, 1.75, 2.35, 3.0].forEach((r, i) => {
  const ring = new T.Mesh(new T.TorusGeometry(r, 0.022 - i * 0.003, 10, 96), i < 2 ? M.neonEdge : M.neonSoft);
  ring.name = `ripple_ring_${i + 1}`;
  ring.rotation.x = -Math.PI / 2;
  ring.position.set(-3.2, 0.02 + i * 0.001, 1.2);
  deck.add(ring);
});
// smaller ripple under the coin column
[0.8, 1.25].forEach((r, i) => {
  const ring = new T.Mesh(new T.TorusGeometry(r, 0.018, 10, 80), M.neonSoft);
  ring.name = `coin_ripple_${i + 1}`;
  ring.rotation.x = -Math.PI / 2;
  ring.position.set(4.3, 0.02, 0.6);
  deck.add(ring);
});
root.add(deck);

/* ── 2. background circuit wall (the "small background items") ── */
const wall = new T.Group(); wall.name = 'circuit_backdrop';
const slabs = [
  [-6.6, 1.1, -5.6, 2.4, 2.2, 0.45], [-4.3, 0.7, -6.2, 1.8, 1.4, 0.4],
  [-2.0, 1.5, -6.6, 1.5, 3.0, 0.4], [0.5, 0.9, -6.3, 2.6, 1.8, 0.45],
  [3.0, 1.3, -5.9, 1.7, 2.6, 0.4], [5.2, 0.8, -6.4, 2.2, 1.6, 0.4],
  [7.3, 1.4, -5.7, 1.9, 2.8, 0.45], [-7.0, 0.8, -4.8, 1.6, 1.6, 0.4],
  [7.4, 0.7, -4.6, 1.7, 1.4, 0.4]
];
slabs.forEach((s, i) => {
  const [x, y, z, w, h, d] = s;
  const m = new T.Mesh(new T.BoxGeometry(w, h, d), M.panel);
  m.name = `backdrop_slab_${i + 1}`;
  m.position.set(x, y, z);
  m.castShadow = true;
  wall.add(m);
  // glowing circuit trace on each slab
  const trace = new T.Mesh(new T.BoxGeometry(w * 0.72, 0.035, 0.02), M.neonEdge);
  trace.name = `backdrop_trace_h_${i + 1}`;
  trace.position.set(x, y + h * 0.22, z + d / 2 + 0.012);
  wall.add(trace);
  const traceV = new T.Mesh(new T.BoxGeometry(0.035, h * 0.5, 0.02), M.neonSoft);
  traceV.name = `backdrop_trace_v_${i + 1}`;
  traceV.position.set(x + w * 0.3, y - h * 0.1, z + d / 2 + 0.012);
  wall.add(traceV);
  const node = new T.Mesh(new T.SphereGeometry(0.07, 14, 10), M.dicePip);
  node.name = `backdrop_node_${i + 1}`;
  node.position.set(x + w * 0.3, y + h * 0.22, z + d / 2 + 0.05);
  wall.add(node);
});
// low side rails framing the deck
[-1, 1].forEach((s, i) => {
  const rail = new T.Mesh(new T.BoxGeometry(0.4, 0.4, 12), M.panel);
  rail.name = `side_rail_${i + 1}`;
  rail.position.set(s * 6.9, 0.2, -0.8);
  wall.add(rail);
  const glow = new T.Mesh(new T.BoxGeometry(0.05, 0.045, 11.4), M.neonEdge);
  glow.name = `side_rail_glow_${i + 1}`;
  glow.position.set(s * 6.9, 0.42, -0.8);
  wall.add(glow);
});
root.add(wall);

/* ── 3. hero die + supporting dice ───────────────────────────── */
const heroDie = buildDie(3.0, 'hero_die');
place(heroDie, -3.2, 3.2, 1.2, 0.42, -0.62, 0.28);
root.add(heroDie);

const midDie = buildDie(1.35, 'mid_die');
place(midDie, -2.3, 0.85, 2.9, -0.35, 0.5, 0.22);
root.add(midDie);

const smallDice = [
  [-5.4, 1.9, 2.3, 0.6], [-5.9, 3.5, 0.3, 0.44], [-1.4, 4.0, -1.0, 0.38],
  [5.9, 1.5, 1.8, 0.55], [6.9, 3.2, -0.5, 0.42], [2.0, 4.4, -2.0, 0.34],
  [-6.4, 0.9, 0.7, 0.5], [6.6, 0.8, 2.1, 0.36]
];
smallDice.forEach(([x, y, z, s], i) => {
  const d = buildDie(s, `mini_die_${i + 1}`);
  place(d, x, y, z, rng(-1, 1), rng(-1, 1), rng(-1, 1));
  root.add(d);
});

/* ── 4. Solana coin ──────────────────────────────────────────── */
function solanaBar(width, skew, thickness) {
  const s = new T.Shape();
  const h = 0.115, w = width / 2;
  s.moveTo(-w + skew, -h); s.lineTo(w + skew, -h);
  s.lineTo(w - skew, h); s.lineTo(-w - skew, h);
  s.closePath();
  const g = new T.ExtrudeGeometry(s, { depth: thickness, bevelEnabled: false });
  g.translate(0, 0, -thickness / 2);
  return g;
}

function buildCoin() {
  const coin = new T.Group(); coin.name = 'solana_coin';
  const disc = new T.Mesh(new T.CylinderGeometry(1.55, 1.55, 0.24, 72), M.coinBody);
  disc.name = 'coin_disc';
  disc.rotation.x = Math.PI / 2;
  disc.castShadow = true;
  coin.add(disc);

  const rim = new T.Mesh(new T.TorusGeometry(1.56, 0.09, 20, 96), M.coinRim);
  rim.name = 'coin_rim';
  coin.add(rim);

  [1.2, 0.9].forEach((r, i) => {
    const groove = new T.Mesh(new T.TorusGeometry(r, 0.018, 12, 88), i === 0 ? M.neonEdge : M.neonSoft);
    groove.name = `coin_groove_${i + 1}`;
    [0.101, -0.101].forEach((z, j) => {
      const g = groove.clone();
      g.name = `coin_groove_${i + 1}_${j === 0 ? 'front' : 'back'}`;
      g.position.z = z * 1.2;
      coin.add(g);
    });
  });

  const barMats = [M.solViolet, M.solBlue, M.solTeal];
  [0.34, 0, -0.34].forEach((y, i) => {
    [1, -1].forEach((side) => {
      const bar = new T.Mesh(solanaBar(1.25, i === 1 ? -0.09 : 0.09 * (i === 0 ? 1 : -1), 0.05), barMats[i]);
      bar.name = `solana_bar_${i + 1}_${side > 0 ? 'front' : 'back'}`;
      bar.position.set(0, y, side * 0.145);
      coin.add(bar);
    });
  });

  // orbiting glow arc behind the coin
  const arc = new T.Mesh(new T.TorusGeometry(1.95, 0.035, 12, 120, Math.PI * 1.35), M.neonEdge);
  arc.name = 'coin_orbit_arc';
  arc.rotation.set(0.9, 0.3, 0.4);
  coin.add(arc);
  return coin;
}
const coin = buildCoin();
place(coin, 4.3, 2.9, 0.6, -0.12, -0.42, 0.16);
root.add(coin);

/* ── 5. floating shards + dust motes (background detail) ─────── */
const shards = new T.Group(); shards.name = 'shards';
const shardSpec = [
  [-6.6, 3.9, -1.8, 0.32], [-4.0, 4.6, -2.8, 0.24], [0.8, 3.2, 3.1, 0.22],
  [4.8, 4.4, -3.0, 0.28], [7.4, 3.7, 1.1, 0.24], [-6.7, 2.4, 2.5, 0.26],
  [7.0, 2.1, -2.0, 0.2], [-0.5, 1.1, 3.9, 0.18], [2.8, 0.8, 3.7, 0.22]
];
shardSpec.forEach(([x, y, z, s], i) => {
  const m = new T.Mesh(new T.OctahedronGeometry(s, 0), M.shard);
  m.name = `shard_${i + 1}`;
  place(m, x, y, z, rng(-1, 1), rng(-1, 1), rng(-1, 1));
  shards.add(m);
});
const moteGeo = new T.IcosahedronGeometry(0.045, 0);
for (let i = 0; i < 46; i++) {
  const mote = new T.Mesh(moteGeo, M.dicePip);
  mote.name = `mote_${i + 1}`;
  mote.position.set(rng(-7, 7), rng(0.35, 5.2), rng(-5.5, 4));
  mote.scale.setScalar(rng(0.5, 1.5));
  shards.add(mote);
}
root.add(shards);

/* ── 6. feature-card plinths (the three hero cards, as objects) ─ */
const cards = new T.Group(); cards.name = 'feature_cards';
[-4.0, 0, 4.0].forEach((x, i) => {
  const card = new T.Mesh(new T.BoxGeometry(3.4, 1.4, 0.16), M.panel);
  card.name = `feature_card_${i + 1}`;
  card.position.set(x, 0.85, 4.6);
  card.rotation.x = -0.16;
  card.castShadow = true;
  cards.add(card);
  const edge = new T.Mesh(new T.BoxGeometry(3.44, 1.44, 0.02), M.neonSoft);
  edge.name = `feature_card_edge_${i + 1}`;
  edge.position.set(x, 0.85, 4.51);
  edge.rotation.x = -0.16;
  cards.add(edge);
  const icon = new T.Mesh(new T.BoxGeometry(0.52, 0.52, 0.06), M.neonEdge);
  icon.name = `feature_card_icon_${i + 1}`;
  icon.position.set(x - 1.2, 0.87, 4.7);
  icon.rotation.x = -0.16;
  cards.add(icon);
  [0.28, 0.02, -0.24].forEach((dy, j) => {
    const line = new T.Mesh(new T.BoxGeometry(j === 0 ? 1.5 : 1.9, 0.09, 0.04), j === 0 ? M.coinRim : M.neonSoft);
    line.name = `feature_card_${i + 1}_line_${j + 1}`;
    line.position.set(x + 0.32, 0.87 + dy, 4.7 + dy * 0.16);
    line.rotation.x = -0.16;
    cards.add(line);
  });
});
root.add(cards);

stage.setObject(root);
